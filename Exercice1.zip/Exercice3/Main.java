package src.Exercice3;

public class Main {
    public static void main(String[] args) {
        HouseCostCalculator houseCostCalculator = new HouseCostCalculator();
        houseCostCalculator.calculateHouseCost();
    }
}
