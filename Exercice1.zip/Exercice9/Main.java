package src.Exercice9;

public class Main {
    public static void main(String[] args) {
        VotingSystem votingSystem = new VotingSystem();
        votingSystem.runVoting();
    }
}
