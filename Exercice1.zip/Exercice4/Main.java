package src.Exercice4;

import javax.swing.*;

public class Main {
    public static void main(String[] args) {
        ServiceCalculator serviceCalculator = new ServiceCalculator();
        serviceCalculator.calculateServiceCost();
    }
}
