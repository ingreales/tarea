package src.Exercice7;

public class Main {
    public static void main(String[] args) {
        LibraryCalculator libraryCalculator = new LibraryCalculator();
        libraryCalculator.calculateMulta();
    }
}
