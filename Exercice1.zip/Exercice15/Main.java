package src.Exercice15;

public class Main {
    public static void main(String[] args) {
        PatternGenerator patternGenerator = new PatternGenerator();
        patternGenerator.generatePattern();
    }
}
