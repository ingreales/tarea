package src.Exercice5;

public class Main {
    public static void main(String[] args) {
        StickerCalculator stickerCalculator = new StickerCalculator();
        stickerCalculator.calculateStickerPrice();
    }
}
