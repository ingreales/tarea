package src.exercice16;

import src.exercice17.Numbers;

public class MainNumbers {
    public static void main(String[] args) {
        Numbers numbers = new Numbers(2,10);

        numbers.showCycle();
    }
}
