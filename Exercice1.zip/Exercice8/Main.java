package src.Exercice8;

public class Main {
    public static void main(String[] args) {
        TriangleVerifier triangleVerifier = new TriangleVerifier();
        triangleVerifier.verifyTriangle();
    }
}
