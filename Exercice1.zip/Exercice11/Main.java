package src.Exercice11;

public class Main {
    public static void main(String[] args) {
        PaymentSystem paymentSystem = new PaymentSystem();
        paymentSystem.runPayment();
    }
}
