package src.Exercice6;

public class Main {
    public static void main(String[] args) {
        MenuCalculator menuCalculator = new MenuCalculator();
        menuCalculator.calculateMenuPrice();
    }
}
