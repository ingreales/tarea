package src.Exercice10;

public class Main {
    public static void main(String[] args) {
        QuizSystem quizSystem = new QuizSystem();
        quizSystem.runQuiz();
    }
}
